from django import forms

from . import Graber_2


class InterfaceForm(forms.Form):
     Article_Table_Name = forms.CharField(max_length=100, label='Article Name')
     Title_Table_Name = forms.CharField(max_length=100, label='Title Name')
     Author_Table_Name = forms.CharField(max_length=100, label='Author Name')
     PageNo_Table_Name = forms.CharField(max_length=100, label='PageNo')
     Abstract_Table_Name = forms.CharField(max_length=100, label='Abstract Name')
     DOI_Table_Name = forms.CharField(max_length=100, label='DOI')


from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect



def UI(request):
   form_class = InterfaceForm
   form = form_class(request.POST or None)
   submitted = False

   if request.method == 'POST':
       form =  InterfaceForm(request.POST)


   if form.is_valid():
        cl = form.cleaned_data
        lb1,lb2,lb3,lb4,lb5,lb6 = tuple(cl.values())
        Graber_2.GetArticleInformation('https://journals.scholarpublishing.org/index.php/TMLAI/issue/view/287',lb1,lb2,lb3,lb4,lb5,lb6)

           # assert False
        return HttpResponseRedirect('/UI?submitted=True')


   else:
        form =  InterfaceForm()
        if 'submitted' in request.GET:
            submitted = True

   return render(request, 'UI/UI.html', {'form': form, 'submitted': submitted})
