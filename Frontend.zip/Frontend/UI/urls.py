from django.urls import path


from . import UI

urlpatterns = [ path('', UI.UI, name='index'),]
