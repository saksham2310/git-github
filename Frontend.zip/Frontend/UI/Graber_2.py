import requests
from bs4 import BeautifulSoup
from urllib.request import urlopen
from urllib.error import HTTPError
from urllib.error import URLError
import re






#Graber Tool
#Developer:Joji Thomas (01-Feb-2020)



def getcl(cl):

    return cl

def GetArticleInformation(TOCurl ,ArticleTableName,TitleTableName,AuthorTableName, PageNoTableName, AbstractTableName , KeywordTableName,DOITableName):
    try:
        hn = []
        ArticleInfo = {        }
        #res = requests.get('http://journals.foundationspeak.com/index.php/ijmss/issue/view/87/showToc')
        res = requests.get(TOCurl)
    except HTTPError as e:
        print(e)
    except URLError:
        print("Server down or incorrect domain")
    else:
    #soup = BeautifulSoup(res.text, 'html.parser')
        soup = BeautifulSoup(res.text, 'html5lib')

    #Journal Title
        journaltitle = soup.title
        journaltitlename = ((journaltitle.getText()).replace('\n', '')).replace('\t', '')
        hn.append({'JournalTitle': journaltitlename})

    #Article Title
        #title = soup.select('.' + ArticleTableName)
        #Author = soup.select('.' + AuthorTableName)
        #Authortags = soup.findAll("td", {"class": "tocAuthors"})
        Authortags = soup.findAll("div", {"class": AuthorTableName})
        title = soup.findAll("div", {"class": TitleTableName})
        PageNoData = soup.findAll("div", {"class": PageNoTableName})
       #urlTags = soup.findAll("a", {"class": TitleTableName})
        #urlTags = soup.findAll("a", {"class": TitleTableName})


        for idx, item in enumerate(title):
            for one_a_tag in title[idx].findAll('a'):  # 'a' tags are for links
                href = one_a_tag['href']
            #titleName = replace(title[idx].getText(),'\n', '')
            #titleName = ((title[idx].getText()).replace('\n', '').replace('\t',''))
            # href = ((urlTags[idx].getText().replace('\n', '').replace('\t', '')))
            #href = item.get('href', None)
            titleName = ((title[idx].getText().replace('\n', '').replace('\t', '')))
            AuthorName = ((Authortags[idx].getText().replace('\n', '').replace('\t', '')))
            PageNo = ((PageNoData[idx].getText().replace('\n', '').replace('\t', '')))
            #AuthorName = ((PageNoData[idx].getText()).replace('\n', '').replace('\t', ''))

            res_2 = requests.get(href)
            soup_details = BeautifulSoup(res_2.text, 'html5lib')
            AbstractDescription = soup_details("div", {"class": AbstractTableName})
            DOIName1=''
            if DOITableName != "":
                DOI = soup_details("div", {"class": DOITableName})
                #print(DOI)
                DOIName = re.findall(r'<a href="https://doi.org/.*', str(DOI))
                #print('DOIName')
                #print(DOIName)
                for DOI1 in DOIName:
                   DOIName1 = DOI1.replace('<a href="https://doi.org/', '').replace('">', '')
                #print(DOIName1)

 #Dummy To test
            #print('Soupdetails')
            #print(soup_details)
            #print(AbstractTableName)
            #print('Abstract')
            #print(AbstractDescription)

            Abstract = ((str(AbstractDescription[0].text).replace("Abstract", "", 1)).replace('\n', '').replace('\t', ''))
            Keyword = soup_details("div", {"class": KeywordTableName})
            KeywordDescription = ((str(Keyword[0].text).replace("Keywords", "", 1)).replace('\n', '').replace('\t', ''))

#Regular Expression
            #patteren = re.compile(r'<div><p><em>([a-zA-z0-9]*)+(<br />)')
            #patteren = re.compile(r'([a-zA-z0-9]*)')
            #x = patteren.findall(str(AbstractDescription[0].text))
            #print(str(AbstractDescription[0].text))

            hn.append({'Articletitle': titleName, 'DOI': DOIName1, 'Page': PageNo, 'link': href, 'Author': AuthorName , 'Abstract': Abstract, 'Keywords': KeywordDescription})


        print(hn)
        # print(hn[2])

GetArticleInformation ('https://journals.scholarpublishing.org/index.php/TMLAI/issue/view/287', 'obj_article_summary', 'title', 'authors', 'pages',  'item abstract', 'item keywords', 'item doi')
